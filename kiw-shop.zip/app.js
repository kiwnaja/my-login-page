// app.js - shared logic (localStorage-based)
(function(){
  // Helpers
  const storage = {
    get(key){ try { return JSON.parse(localStorage.getItem(key)) || []; } catch(e){ return []; } },
    set(key, val){ localStorage.setItem(key, JSON.stringify(val)); }
  };

  function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }

  // Users
  function getUsers(){ return storage.get('kiw_users'); }
  function saveUsers(u){ storage.set('kiw_users', u); }
  function addUser({email, username, password}){
    const users = getUsers(); if(users.find(x=>x.email===email)) throw new Error('อีเมลนี้ถูกใช้แล้ว');
    if(users.find(x=>x.username===username)) throw new Error('ชื่อผู้ใช้นี้ถูกใช้แล้ว');
    users.push({id: uid(), email, username, password}); saveUsers(users);
  }

  // Session
  function setCurrentUser(user){ localStorage.setItem('kiw_current', JSON.stringify(user)); }
  function getCurrentUser(){ try{return JSON.parse(localStorage.getItem('kiw_current'));}catch(e){return null;} }
  function logout(){ localStorage.removeItem('kiw_current'); window.location.href='login.html'; }

  // Products
  function getProducts(){ return storage.get('kiw_products'); }
  function saveProducts(p){ storage.set('kiw_products', p); }
  function addProduct({title, code, validity, price}){
    const p = getProducts(); p.push({id: uid(), title, code, validity, price: parseFloat(price||0), createdAt: new Date().toISOString()}); saveProducts(p);
  }
  function updateProduct(id, data){ const p = getProducts(); const idx = p.findIndex(x=>x.id===id); if(idx>=0){ p[idx] = {...p[idx], ...data}; saveProducts(p); } }
  function deleteProduct(id){ storage.set('kiw_products', getProducts().filter(x=>x.id!==id)); }

  // Orders
  function getOrders(){ return storage.get('kiw_orders'); }
  function saveOrders(o){ storage.set('kiw_orders', o); }
  function addOrder({productId, buyerUsername, buyerEmail, contact}){
    const orders = getOrders(); orders.push({id: uid(), productId, buyerUsername, buyerEmail, contact, status:'pending', createdAt:new Date().toISOString()}); saveOrders(orders); return orders[orders.length-1];
  }
  function setOrderStatus(id, status){ const o = getOrders(); const idx = o.findIndex(x=>x.id===id); if(idx>=0){ o[idx].status = status; saveOrders(o); } }

  // Expose to window for pages
  window.KIW = {
    uid, storage, // helpers
    // users
    getUsers, saveUsers, addUser,
    // session
    setCurrentUser, getCurrentUser, logout,
    // products
    getProducts, saveProducts, addProduct, updateProduct, deleteProduct,
    // orders
    getOrders, saveOrders, addOrder, setOrderStatus
  };

  // Initialize default data only if not exist
  if(!localStorage.getItem('kiw_products')){
    saveProducts([
      {id: uid(), title: 'Blox Fruits - Lv2450', code: 'BF-2450-XYZ', validity: 'ถาวร', price: 150},
      {id: uid(), title: 'Free Fire - Elite Pack', code: 'FF-EL-2025', validity: '1 เดือน', price: 200}
    ]);
  }
  if(!localStorage.getItem('kiw_users')){
    saveUsers([]);
  }
  if(!localStorage.getItem('kiw_orders')){
    saveOrders([]);
  }
})();